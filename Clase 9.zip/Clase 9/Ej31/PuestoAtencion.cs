﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej31//Hacer 33
{
    class PuestoAtencion
    {
        public enum Puesto
        {
            Caja1,
            Caja2
        }
        private static int numeroActual;
        private Puesto puesto;
        #region Propiedades
        public int NumeroActual
        {
            get
            {
                numeroActual++;
                return numeroActual;
            }
        }
        #endregion
        #region Constructores
        static PuestoAtencion()
        {
            numeroActual = 0;
        }
        public PuestoAtencion(Puesto puesto)
        {
            this.puesto = puesto;
        }
        #endregion
        #region Metodos
        public bool Atender(Cliente cli)
        {
            bool retorno = true;
            System.Threading.Thread.Sleep(1000);
            return retorno;
        }
        #endregion
    }
}
