﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej31//Hacer 33
{
    class Cliente
    {
        private string nombre;
        private int numero;
        #region Propiedades
        public string Nombre
        {
            get
            {
                return nombre;
            }
            set
            {
                this.nombre = value;
            }
        }
        public int Numero
        {
            get
            {
                return numero;
            }
        }
        #endregion
        #region Constructores
        public Cliente(int numero)
        {
            this.numero = numero;
        }
        public Cliente(int numero,string nombre):this(numero)
        {
            this.nombre = nombre;
        }
        #endregion
        #region Metodos
        public static bool operator ==(Cliente c1,Cliente c2)
        {
            bool retorno = false;
            if(c1 == c2)
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Cliente c1, Cliente c2)
        {
            bool retorno = false;
            if (c1 != c2)
            {
                retorno = true;
            }
            return retorno;
        }
        #endregion
    }
}
