﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej31//Hacer 33
{
    class Negocio
    {
        private PuestoAtencion caja;
        private Queue<Cliente> clientes;
        private string nombre;
        #region Propiedades

        #endregion
        #region Constructores
        private Negocio()
        {
            this.caja = new PuestoAtencion(PuestoAtencion.Puesto.Caja1);
            this.clientes = new Queue<Cliente>();
        }
        public Negocio(string nombre) : this()
        {
            this.nombre = nombre;
        }
        #endregion
        #region Metodos
        public static bool operator !=(Negocio n, Cliente c)
        {
            bool retorno = false;
            return retorno;
        }
        public static bool operator ==(Negocio n, Cliente c)
        {
            bool retorno = false;
            return retorno;
        }
        public static bool operator ~(Negocio n)
        {
            bool retorno = false;
            return retorno;
        }
        public static bool operator +(Negocio n,Cliente c)
        {
            bool retorno = false;
            foreach(Cliente cliente in n.clientes)
            {
                if(cliente==c)
                {
                    retorno = true;
                }
            }
            if(!retorno)
            {
                
            }
            return retorno;
        }
        #endregion
    }
}
