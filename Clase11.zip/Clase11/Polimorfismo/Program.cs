﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polimorfismo
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Figura> figuras = new List<Figura>();
            string texto;
            double sup;
            double per;
            figuras.Add(new Circulo(4));
            figuras.Add(new Rectangulo(4, 5));
            figuras.Add(new Cuadrado(4));
            figuras[0].GetType();
            texto = figuras[0].Dibujar();
            sup = figuras[0].CalcularSuperficie();
            per = figuras[0].CalcularPerimetro();
            Console.WriteLine("{0} {1} {2}",texto,sup,per);
            Console.ReadKey();
            Console.Clear();
            figuras[1].GetType();
            texto = figuras[1].Dibujar();
            sup = figuras[1].CalcularSuperficie();
            per = figuras[1].CalcularPerimetro();
            Console.WriteLine("{0} {1} {2}", texto, sup, per);
            Console.ReadKey();
            Console.Clear();
            figuras[2].GetType();
            texto = figuras[2].Dibujar();
            sup = figuras[2].CalcularSuperficie();
            per = figuras[2].CalcularPerimetro();
            Console.WriteLine("{0} {1} {2}", texto, sup, per);
            Console.ReadKey();
            Console.Clear();
        }
    }
}
