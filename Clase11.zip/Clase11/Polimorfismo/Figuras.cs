﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polimorfismo
{
    abstract class Figura
    {
        public virtual string Dibujar()
        {
            string retorno = "Dibujando forma...";
            return retorno;
        }
        public abstract double CalcularSuperficie();
        public abstract double CalcularPerimetro();
    }
    class Rectangulo : Figura
    {
        double altura;
        double basee;

        public Rectangulo(double a, double b)
        {
            this.altura = a;
            this.basee = b;
        }

        public override string Dibujar()
        {
            string retorno = "Dibujando Rectangulo...";
            return retorno;
        }
        public override double CalcularPerimetro()
        {
            double perimetro = 2*this.altura + 2*this.basee;
            return perimetro;
        }
        public override double CalcularSuperficie()
        {
            double superficie = this.altura * this.basee;
            return superficie;
        }
    }
    sealed class Circulo : Figura
    {
        float radio;

        public Circulo(float radio)
        {
            this.radio = radio;
        }

        public override string Dibujar()
        {
            string retorno = "Dibujando Circulo...";
            return retorno;
        }
        public override double CalcularSuperficie()
        {
            double superficie = 3.14 * this.radio * this.radio;
            return superficie;
        }
        public override double CalcularPerimetro()
        {
            double perimetro = 2 * 3.14 * this.radio;
            return perimetro;
        }
    }
    
    sealed class Cuadrado : Rectangulo
    {
        double lado;
        public Cuadrado(double lado) :base(lado,lado)
        {

        }

        public override double CalcularPerimetro()
        {
            double perimetro = 4*lado;
            return perimetro;
        }
        public override double CalcularSuperficie()
        {
            double superficie = this.lado * this.lado;
            return superficie;
        }

    }
}
