﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej33
{
    class Libro
    {
        List<string> paginas;

        #region Constructores
        public Libro()
        {
            this.paginas = new List<string>();
        }
        #endregion
        #region Propiedades
        public string this[int index]
        {
            get
            {
                int cantidad;
                string leer = "";
                cantidad = this.paginas.Count;
                if(index<=cantidad && index >= 0)
                {
                    leer = paginas[index];
                }
                return leer;
            }
            set
            {
                int cantidad;
                cantidad = this.paginas.Count;
                if(cantidad<=index && index>=0)
                {
                    this.paginas.Add(value);
                }
                else
                {
                    paginas[index] = value;
                }
            }
        }
        #endregion

    }
}
