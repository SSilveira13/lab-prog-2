﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EjemploForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.txtNombre.Text = "Ingrese su nombre.";
        }

        private void Presionar(object sender, EventArgs e)
        {
            string nombre = this.txtNombre.Text;
            DialogResult result = MessageBox.Show("Hola " + nombre, "Saludo", MessageBoxButtons.RetryCancel, MessageBoxIcon.Information);

            if(result == DialogResult.Retry)
            {
                Form1 form = new Form1();
                form.ShowDialog();
            }
        }

        
    }
}
