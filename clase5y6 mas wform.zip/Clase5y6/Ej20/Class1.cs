﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    class Pesos
    {
        private double cantidad;
        private static double cotizRespectoDolar;

        public Pesos(double cantidad)
        {
            this.cantidad = cantidad;
        }

        #region Constructores
        public void pesos(double cantidad, double cotiz)
        {
            this.cantidad = cantidad;
            cotizRespectoDolar = cotiz;
        }
        public void pesos(double cantidad)
        {
            pesos(cantidad, 38.33);
        }
        private void pesos()
        {
            pesos(0);
        }
        #endregion

        #region Metodos

        #region Geters
        public static double getCotiz()
        {
            return cotizRespectoDolar;
        }
        public double getCantidad()
        {
            return this.cantidad;
        }
        #endregion
        #region Conversores
        public static explicit operator Dolares(Pesos p)
        {
            double cambio = p.cantidad * cotizRespectoDolar;
            Dolares retorno = new Dolares(cambio);
            return retorno;
        }
        public static explicit operator Euros(Pesos p)
        {
            double euroDolar = Euros.getCotiz();
            double cambio = p.cantidad * cotizRespectoDolar * euroDolar;
            Euros retorno = new Euros(cambio);
            return retorno;
        }
        #endregion
        #region Comparadores
        public static bool operator ==(Pesos p1, Pesos p2)
        {
            return p1 == p2;
        }
        public static bool operator !=(Pesos p1, Pesos p2)
        {
            return !(p1 == p2);
        }

        public static bool operator ==(Pesos p, Dolares d)
        {
            return (Dolares)p == d;
        }
        public static bool operator !=(Pesos p, Dolares d)
        {
            return !((Dolares)p == d);
        }

        public static bool operator ==(Pesos p, Euros e)
        {
            return (Euros)p == e;
        }
        public static bool operator !=(Pesos p, Euros e)
        {
            return !((Euros)p == e);
        }
        #endregion
        #region Aritmetica
        public static Pesos operator +(Pesos p, Euros e)
        {
            Pesos cambio = (Pesos)e;
            double cantidad = p.cantidad + cambio.cantidad;
            Pesos retorno = new Pesos(cantidad);
            return retorno;
        }
        public static Pesos operator +(Pesos p, Dolares d)
        {
            Pesos cambio = (Pesos)d;
            double cantidad = p.cantidad + cambio.cantidad;
            Pesos retorno = new Pesos(cantidad);
            return retorno;
        }

        public static Pesos operator -(Pesos p, Euros e)
        {
            Pesos cambio = (Pesos)e;
            double cantidad = p.cantidad - cambio.cantidad;
            if (cantidad < 0)
            {
                cantidad = cantidad * -1;
            }
            Pesos retorno = new Pesos(cantidad);
            return retorno;
        }
        public static Pesos operator -(Pesos p, Dolares d)
        {
            Pesos cambio = (Pesos)d;
            double cantidad = p.cantidad - cambio.cantidad;
            if(cantidad<0)
            {
                cantidad = cantidad * -1;
            }
            Pesos retorno = new Pesos(cantidad);
            return retorno;
        }
        #endregion
        #endregion
    }

    class Euros
    {
        private double cantidad;
        private static double cotizRespectoDolar;
        private double cambio;

        public Euros(double cambio)
        {
            this.cambio = cambio;
        }

        #region Constructores
        public void euros(double cantidad, double cotiz)
        {
            this.cantidad = cantidad;
            cotizRespectoDolar = cotiz;
        }
        public void euros(double cantidad)
        {
            euros(cantidad, 1.16);
        }
        private void euros()
        {
            euros(0);
        }
        #endregion
        #region Geters
        public static double getCotiz()
        {
            return cotizRespectoDolar;
        }
        public double getCantidad()
        {
            return this.cantidad;
        }
        #endregion

        public static explicit operator Dolares(Euros e)
        {
            double cambio = e.cantidad * cotizRespectoDolar;
            Dolares retorno = new Dolares(cambio);
            return retorno;
        }
        public static explicit operator Pesos(Euros e)
        {
            double dolarPeso = Pesos.getCotiz();
            double cambio = e.cantidad * cotizRespectoDolar * dolarPeso;
            Pesos retorno = new Pesos(cambio);
            return retorno;

        }
    }
    class Dolares
    {
        private double cantidad;
        private static double cotizRespectoDolar;
        private double cambio;

        public Dolares(double cambio)
        {
            this.cambio = cambio;
        }

        #region Constructores
        public void dolares(double cantidad, double cotiz)
        {
            this.cantidad = cantidad;
            cotizRespectoDolar = cotiz;
        }
        public void dolares(double cantidad)
        {
            dolares(cantidad, 1);
        }
        private void dolares()
        {
            dolares(0);
        }
        #endregion

        public static double getCotiz()
        {
            return cotizRespectoDolar;
        }
        public double getCantidad()
        {
            return this.cantidad;
        }

        public static explicit operator Pesos(Dolares d)
        {
            double cambio = d.cantidad * cotizRespectoDolar;
            Pesos retorno = new Pesos(cambio);
            return retorno;
        }
        public static explicit operator Euros(Dolares d)
        {
            double cambio = d.cantidad * cotizRespectoDolar;
            Euros retorno = new Euros(cambio);
            return retorno;
        }
    }
}
    
