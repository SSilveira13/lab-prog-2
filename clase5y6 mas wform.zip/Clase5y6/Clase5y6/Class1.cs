﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elemento
{
    class Suma
    {
        private int cantidadSumas;

        public void Sumador(int cantidadSumas)
        {
            this.cantidadSumas = cantidadSumas;
        }
        public void Sumador()
        {
            Sumador(0);
        }

        public long Sumar(long a, long b)
        {
            long retorno;
            retorno = a + b;
            return retorno;
        }
        public string Sumar(string a, string b)
        {
            string retorno;
            retorno = string.Format("{0}{1}", a, b);
            return retorno;
        }

        public static explicit operator int(Suma s)
        {
            int retorno=0;

            return retorno;
        }

        /*public static implicit operator +(Suma s1, Suma s2)
        {

        }*/
    }


}
