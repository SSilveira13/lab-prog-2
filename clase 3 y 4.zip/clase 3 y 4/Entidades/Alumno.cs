﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades// Ctrl + . para  agregar la biblioteca necesaria
{
    class Alumno
    {
        #region Atributos
        private byte nota1;
        private byte nota2;
        private float notaFinal;
        private string apellido;
        private int legajo;
        private string nombre;
        #endregion
        #region Constructor
        /// <summary>
        /// Construye el objeto alumno asignando los valores a sus atributos.
        /// </summary>
        /// <param name="apellido">Apellido del alumno.</param>
        /// <param name="legajo">Legajo del alumno</param>
        /// <param name="nombre">Nombre del alumno</param>
        public Alumno(string apellido,int legajo,string nombre)
        {
            this.apellido = apellido;
            this.legajo = legajo;
            this.nombre = nombre;
        }
        #endregion
        #region Merodos
        /// <summary>
        /// Calcula la nota final segun las notas en los parciales.
        /// </summary>
        public void CalcularFinal()
        {
            Random aleatorio = new Random();
            if (this.nota1 >= 4 && this.nota2 >=4)
            {
                this.notaFinal = aleatorio.Next(1, 11);
            }
            else
            {
                this.notaFinal = -1;
            }
        }
        /// <summary>
        /// Carga la nota del alumno.
        /// </summary>
        /// <param name="notaUno">Nota del prime parcial.</param>
        /// <param name="notaDos">Nota del segundo parcial.</param>
        public void Estudiar(byte notaUno,byte notaDos)
        {
            this.nota1 = notaUno;
            this.nota2 = notaDos;
        }
        /// <summary>
        /// Genera un texto(String) con todos los datos y notas del alumno.
        /// </summary>
        /// <returns>Retorna el texto generado.</returns>
        public string Mostrar()
        {
            string retorno = string.Empty;
            // retorno += String.Format("Nombre: {0}",this.nombre); hace lo mismo que el console.writeline para concatenar.
            // "\n" deja un enter al igual que en ansi c.
            retorno = "Nombre: " + this.nombre + " Apellido: " + this.apellido + " Legajo: " + this.legajo + " Nota 1: " + this.nota1 + " Nota 2: " + this.nota2;
            if(this.notaFinal==-1)
            {
                retorno = retorno + " Alumno no aprobado.";
            }
            else
            {
                retorno = retorno + " Nota de final: " + this.notaFinal + ".";
            }
            return retorno;
        }
        #endregion
    }
}
