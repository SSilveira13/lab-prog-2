﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase_3_y_4// Ctrl + . para  agregar la biblioteca necesaria
{
    class Program
    {
        static void Main(string[] args)
        {
            //Instancio e inicializo los objetos Alumno.
            byte auxNotaUno;
            byte auxNotaDos;
            Alumno alumno1 = new Alumno("pepe", 1, "pepe");
            Alumno alumno2 = new Alumno("sasa", 2, "sasa");
            Alumno alumno3 = new Alumno("lala", 3, "lala");
            //Cargo las notas de cada alumno y calculo la nota final
            Console.WriteLine("Primer alumno.");
            Console.WriteLine("Ingrese la primera nota: ");
            auxNotaUno = Convert.ToByte(Console.ReadLine());
            Console.WriteLine("Ingrese la segunda nota: ");
            auxNotaDos = Convert.ToByte(Console.ReadLine());
            alumno1.Estudiar(auxNotaUno, auxNotaDos);
            alumno1.CalcularFinal();

            Console.WriteLine("Segundo alumno.");
            Console.WriteLine("Ingrese la primera nota: ");
            auxNotaUno = Convert.ToByte(Console.ReadLine());
            Console.WriteLine("Ingrese la segunda nota: ");
            auxNotaDos = Convert.ToByte(Console.ReadLine());
            alumno2.Estudiar(auxNotaUno, auxNotaDos);
            alumno2.CalcularFinal();

            Console.WriteLine("Tercer alumno.");
            Console.WriteLine("Ingrese la primera nota: ");
            auxNotaUno = Convert.ToByte(Console.ReadLine());
            Console.WriteLine("Ingrese la segunda nota: ");
            auxNotaDos = Convert.ToByte(Console.ReadLine());
            alumno3.Estudiar(auxNotaUno, auxNotaDos);
            alumno3.CalcularFinal();
            //Muestro la informacion de los alumnos
            Console.WriteLine(alumno1.Mostrar());
            Console.WriteLine(alumno2.Mostrar());
            Console.WriteLine(alumno3.Mostrar());
            //cw + TAB + TAB genera un console.writeLine() instantaneo!!!!!!!!!
            Console.ReadKey();
        }
    }
}
