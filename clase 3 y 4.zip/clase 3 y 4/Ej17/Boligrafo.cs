﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej17// Ctrl + . para  agregar la biblioteca necesaria
{
    public class Boligrafo
    {
        #region Atributos
        private const short cantidadTintaMaxima=100;
        private ConsoleColor color;
        private short tinta;
        #endregion
        #region Constructor
        public Boligrafo(ConsoleColor color, short tinta)
        {
            this.color = color;
            this.tinta = tinta;
        }
        #endregion
        #region Metodos
        public ConsoleColor GetColor()
        {
            ConsoleColor retorno;
            retorno = this.color;
            return retorno;
        }

        public short GetTinta()
        {
            short retorno;
            retorno = this.tinta;
            return retorno;
        }

        private void SetTinta(short tinta)
        {
            if(this.tinta >=0 && this.tinta <= cantidadTintaMaxima)
            {

            }
            else
            {

            }
        }


        public void Recargar()
        {
            while(this.tinta < cantidadTintaMaxima)
            {
                this.tinta++;
            }
        }


        public bool Pintar(short gasto/*, out string dibujo*/)
        {
            bool retorno= false;
            return retorno;
        }




        #endregion 
    }
}
