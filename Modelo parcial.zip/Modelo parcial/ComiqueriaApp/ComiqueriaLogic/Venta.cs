﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    sealed class Venta
    {
        private DateTime fecha;
        private int porcentajeIva;
        private double precioFinal;
        private Producto producto;
        #region Constructores
        static Venta()
        {
            
        }
        #endregion
    }
}
