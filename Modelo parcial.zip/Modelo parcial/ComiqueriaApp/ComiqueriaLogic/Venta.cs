﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    sealed class Venta
    {
        private DateTime fecha;
        static int porcentajeIva;
        private double precioFinal;
        private Producto producto;
        private double precioUnidad;
        #region Constructores
        static Venta()
        {
            porcentajeIva = 21;
        }
        internal Venta(Producto producto,int cantidad)
        {

            vender(cantidad);
        }
        #endregion
        #region Propiedades
        public DateTime Fecha
        {
            get
            {
                DateTime fecha = this.fecha;
                return fecha;
            }
        }
        #endregion
        #region Metodos
        private void vender(int cantidad)
        {
            int stock = producto.Stock;
            producto.Stock = stock - cantidad;
            fecha = DateTime.Now;
            precioFinal = calcularPrecioFinal(precioUnidad, cantidad);
        }
        static public double calcularPrecioFinal(double precioUnidad,int cantidad)
        {
            double precioTotal;
            precioTotal = precioUnidad * cantidad;
            precioTotal = precioTotal + (precioTotal * porcentajeIva / 100);
            return precioTotal;
        }
        public string obtenerDescripcionBreve()
        {
            StringBuilder constructor = new StringBuilder();
            constructor.AppendFormat("{0} -", this.fecha);
            constructor.AppendFormat("{0} -", producto.Descripcion);
            constructor.AppendFormat("{0}", this.precioFinal);
            return constructor.ToString();
        }
        #endregion
    }
}
