﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    class Comiqueria
    {
        List<Producto> productos;
        List<Venta> ventas;

        #region Constructores
        public Comiqueria()
        {
            this.productos = new List<Producto>();
            this.ventas = new List<Venta>();
        }
        #endregion
        #region Indexadores
        public Producto this[Guid codigo]
        {
            get
            {
                Producto retorno = null;
                foreach (Producto identificador in productos)
                {
                    if(codigo == (Guid)identificador)
                    {
                        retorno = identificador;
                    }
                }
                return retorno;
            }
        }
        #endregion
        #region Metodos
        public explicit operator ==()
        #endregion
    }
}
