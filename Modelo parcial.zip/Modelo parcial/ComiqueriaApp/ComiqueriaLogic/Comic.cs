﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    class Comic : Producto
    {
        private string autor;
        public TipoComic tipoComic;

        public enum TipoComic
        {
            Occidental,
            Oriental
        }
        #region Constructores
        public Comic(string descripcion,int stock,double precio,string autor, TipoComic tipoComic) : base(descripcion, stock, precio)
        {
            this.autor = autor;
            this.tipoComic = tipoComic;
        }
        #endregion
        #region Metodos
        public override string ToString()
        {
            string auxiliar = base.ToString();
            StringBuilder resumen = new StringBuilder();
            resumen.AppendFormat("{0}\n", auxiliar);
            resumen.AppendFormat("Autor: {0}\n", this.autor);
            resumen.AppendFormat("Tipo de comic: {0}", this.tipoComic);
            return resumen.ToString();
        }
        #endregion
    }
}
