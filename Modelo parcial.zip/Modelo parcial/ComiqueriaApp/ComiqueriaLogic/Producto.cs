﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    abstract class Producto
    {
        private Guid codigo;
        private string descripcion;
        private double precio;
        private int stock;

        #region Constructor
        protected Producto(string descripcion, int stock, double precio)
        {
            this.codigo = Guid.NewGuid();
            this.descripcion = descripcion;
            this.stock = stock;
            this.precio = precio;
        }
        #endregion
        #region Propiedades
        public int Stock
        {
            get
            {
                return Stock;
            }
            set
            {
                if (value >= 0)
                {
                    Stock = value;
                }
            }
        }
        public double Percio
        {
            get { return Percio; }
        }
        public string Descripcion
        {
            get { return Descripcion; }
        }
        #endregion
        #region Metodos
        public override string ToString()
        {
            StringBuilder resumen = new StringBuilder();
            resumen.AppendFormat("Descripcion: {0}\n", this.descripcion);
            resumen.AppendFormat("Codigo: {0}\n", this.codigo);
            resumen.AppendFormat("Precio: ${0:0.00}\n", this.precio);
            resumen.AppendFormat("Stock: {0} unidades", this.stock);
            return resumen.ToString();
        }
        public static explicit operator Guid(Producto p)
        {
            return p.codigo;
        }
        #endregion
    }
}
