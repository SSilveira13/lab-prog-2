﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio6
{
    class Program
    {
        static void Main(string[] args)
        {
            int anioMenor;
            int anioMayor;
            int iterador;
            Console.WriteLine("Ingrese un año:");
            anioMenor = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese un año mayor al anterior:");
            anioMayor = Convert.ToInt32(Console.ReadLine());
            for(iterador=anioMenor;iterador<=anioMayor;iterador++)
            {
                if(iterador%4==0)
                {
                    if(iterador%100!=0)
                    Console.WriteLine("año bisiesto: {0}",iterador);
                }
            }
            Console.ReadKey();
        }
    }
}
