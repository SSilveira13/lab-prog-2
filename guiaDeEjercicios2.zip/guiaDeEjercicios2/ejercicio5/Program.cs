﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio5
{
    class Program
    {
        static void Main(string[] args)
        {
            int numeroIngresado;
            int contador;
            int menor;
            int mayor;
            int acumuladorMenor=0;
            int acumuladorMayor=0;
            Console.WriteLine("Ingrese un numero: ");
            numeroIngresado = Convert.ToInt32(Console.ReadLine());
            for(contador=1;contador<=numeroIngresado;contador++)
            {
                //Console.ReadKey();
                acumuladorMayor = 0;
                acumuladorMenor = 0;
                menor = contador;
                mayor = contador;
                //
                Console.WriteLine("{0}", contador);
                do
                {
                    menor--;
                    acumuladorMenor = acumuladorMenor + menor;
                    //Console.Write("1");
                } while (menor >= 1);
                //Console.WriteLine("{0}", acumuladorMenor);
                do
                {
                    mayor++;
                    acumuladorMayor = acumuladorMayor + mayor;
                    //Console.Write("2");
                } while (acumuladorMayor < acumuladorMenor) ;
                //Console.WriteLine("{0}",acumuladorMayor);
                if (acumuladorMayor == acumuladorMenor)
                {
                    //Console.Write("3");
                    Console.WriteLine("Centro numerico: {0}",contador);
                }
            }
            Console.ReadKey();
        }
    }
}
