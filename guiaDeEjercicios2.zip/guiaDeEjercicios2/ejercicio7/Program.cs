﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio7
{
    class Program
    {
        static void Main(string[] args)
        {//7922 dias desde que naci(13-12-1997)
            int dia;
            int mes;
            int anio;
            int diaActual=DateTime.Now.Day;
            int mesActual= DateTime.Now.Month;
            int anioActual= DateTime.Now.Year;
            int acumulador=0;
            int iterador;
            int resultante=0;
            int reiterador;
            Console.WriteLine("Ingrese dia:");
            dia = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese mes:");
            mes = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese año:");
            anio = Convert.ToInt32(Console.ReadLine());
            for(iterador=anio;iterador<=anioActual;iterador++)
            {
                if (iterador % 4 == 0)
                {
                    if (iterador % 100 != 0)
                    {
                        acumulador++;
                    }
                }
                for (reiterador = 1; reiterador <= 12; reiterador++)
                {
                    switch(reiterador)
                    {
                        case 2:
                            resultante = resultante + 28;
                            break;
                        case 4:
                        case 6:
                        case 9:
                        case 11:
                            resultante = resultante + 30;
                            break;
                        case 1:
                        case 3:
                        case 5:
                        case 7:
                        case 8:
                        case 10:
                        case 12:
                            resultante = resultante + 31;
                            break;
                    }
                }
            }

            resultante = resultante + acumulador;

            Console.WriteLine("Dias totales: {0}",resultante);

            Console.ReadKey();
        }
    }
}
