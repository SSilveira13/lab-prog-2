﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio8
{
    class Program
    {
        static void Main(string[] args)
        {
            string nombre;
            int horas;
            int antiguedad;
            int valorHora;
            int empleados;
            int iteraciones;
            int bruto;
            int descuento;
            int neto;
            Console.WriteLine("Cantiadad de empleados a ingresar:");
            empleados = Convert.ToInt32(Console.ReadLine());
            for(iteraciones = 1;iteraciones<=empleados;iteraciones++)
            {
                Console.WriteLine("Ingrese el nombre del empleado:");
                nombre = Console.ReadLine();
                Console.WriteLine("Ingrese el valor por hora:");
                valorHora = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Ingrese las horas trabajadas en el mes:");
                horas = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Ingrese la antiguedad del empleado:");
                antiguedad = Convert.ToInt32(Console.ReadLine());

                bruto = valorHora * horas + antiguedad * 150;
                descuento = bruto * 13 / 100;
                neto = bruto - descuento;

                Console.WriteLine("Nombre: {0} Antiguedad: {1} años Valor por hora trabajada: ${2}",nombre,antiguedad,valorHora);
                Console.WriteLine("Bruto: ${0} Descuento: ${1} Neto: ${2}",bruto,descuento,neto);
                Console.ReadKey();
            }
            Console.ReadKey();
        }
    }
}
