﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio9
{
    class Program
    {
        static void Main(string[] args)
        {
            int iteraciones;
            int imprecion;
            int numero;
            int asteriscos;
            Console.WriteLine("Ingrese la cantidad de pisos de la piramide:");
            numero = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            for (iteraciones=1;iteraciones<=numero;iteraciones++)
            {
                asteriscos = iteraciones;
                asteriscos = asteriscos + (asteriscos-1);
                for(imprecion=1;imprecion<=asteriscos;imprecion++)
                {
                    Console.Write("*");
                }
                Console.WriteLine("");
                Console.WriteLine("");
            }
            Console.ReadKey();
        }
    }
}
