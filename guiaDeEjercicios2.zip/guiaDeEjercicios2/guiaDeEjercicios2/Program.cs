﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace guiaDeEjercicios2
{
    class Program
    {
        static void Main(string[] args)
        {

            int acumulador=0;
            int numerosPerfectos=0;
            int numero=0;
            int divisor;
            Console.WriteLine("Numeros perfectos: ");
            while(numerosPerfectos < 4)
            {
                numero++;
                acumulador = 0;
                for(divisor=1;divisor<numero;divisor++)
                {
                    if(numero%divisor==0)
                    {
                        acumulador = acumulador + divisor;
                    }
                }
                if(acumulador == numero)
                {
                    numerosPerfectos++;
                    Console.WriteLine("{0}", numero);
                }
            }
            Console.ReadKey();
        }
    }
}
