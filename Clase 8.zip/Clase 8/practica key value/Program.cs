﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practica_key_value
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> diccionario = new Dictionary<string, string>();
            string nombre;
            string dni;
            int i;
            for (i = 0; i <= 4; i++)
            {
                Console.WriteLine("Ingrese nombre y apellido:");
                nombre = Console.ReadLine();
                Console.WriteLine("Ingrese dni:");
                dni = Console.ReadLine();
                diccionario.Add(dni, nombre);
            }
            foreach (KeyValuePair <string,string>valores  in diccionario)
            {
                Console.WriteLine("{0}",valores);
            }
            Console.ReadKey();
        }
    }
}
