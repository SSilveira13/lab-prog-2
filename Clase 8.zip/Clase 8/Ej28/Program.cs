﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej28
{
    class Program
    {
        static void Main(string[] args)
        {

            List<int> lista = new List<int>();//esto va dentro de un metodo privado y estatico
            Random random = new Random();
            int i;
            int numeroRandom;
            for(i=0;i<=4;i++)
            {
                numeroRandom = random.Next(0, 100);
                lista.Add(numeroRandom);
            }
            foreach(int numero in lista)
            {
                Console.Write("{0} ",numero);
            }
            Console.WriteLine("");
            lista.Sort(Comparar);
            foreach (int numero in lista)
            {
                Console.Write("{0} ", numero);
            }

            Console.ReadKey();

            


        }
        public static int Comparar(int x, int y)
        {
            int retorno = 0;
            if(x > y)
            {
                retorno = -1;
            }
            else if (x < y)
            {
                retorno = 1;
            }
            else if(x == y)
            {
                retorno = 0;
            }
            return retorno;
        }
    }
}
