﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practica_de_lista_stack_y_enqueue
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> lista = new List<int>();
            Stack<int> pila = new Stack<int>();
            Queue<int> cola = new Queue<int>();
            Random random = new Random();
            int numero;
            int i;
            for(i=0;i<=4;i++)
            {
                numero = random.Next(0, 100);
                lista.Add(numero);
            }
            foreach(int n in lista)
            {
                Console.Write("{0} ",n);
                pila.Push(n);
            }
            Console.WriteLine("");
            foreach (int n in pila)
            {
                Console.Write("{0} ", n);
                cola.Enqueue(n);
            }
            Console.WriteLine("");
            foreach (int n in cola)
            {
                Console.Write("{0} ", n);
            }
            Console.ReadKey();
        }
    }
}
