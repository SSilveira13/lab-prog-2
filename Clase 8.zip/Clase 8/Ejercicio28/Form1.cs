﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio28
{
    public partial class ContadorDePalabras : Form
    {
        public ContadorDePalabras()
        {
            InitializeComponent();
        }

        private void Calcular_OnClick(object sender, EventArgs e)
        {
            Dictionary<string, int> Diccionarios = new Dictionary<string, int>();
            List<String> Texto = new List<string>();
            CajaDeTexto.ToString();
        }
    }
}
