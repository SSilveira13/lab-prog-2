﻿namespace Ejercicio28
{
    partial class ContadorDePalabras
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.CajaDeTexto = new System.Windows.Forms.RichTextBox();
            this.BotonDeCalculo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // CajaDeTexto
            // 
            this.CajaDeTexto.Location = new System.Drawing.Point(0, 0);
            this.CajaDeTexto.Name = "CajaDeTexto";
            this.CajaDeTexto.Size = new System.Drawing.Size(448, 366);
            this.CajaDeTexto.TabIndex = 0;
            this.CajaDeTexto.Text = "";
            // 
            // BotonDeCalculo
            // 
            this.BotonDeCalculo.Location = new System.Drawing.Point(361, 372);
            this.BotonDeCalculo.Name = "BotonDeCalculo";
            this.BotonDeCalculo.Size = new System.Drawing.Size(75, 23);
            this.BotonDeCalculo.TabIndex = 1;
            this.BotonDeCalculo.Text = "Calcular";
            this.BotonDeCalculo.UseVisualStyleBackColor = true;
            this.BotonDeCalculo.Click += new System.EventHandler(this.Calcular_OnClick);
            // 
            // ContadorDePalabras
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(448, 407);
            this.Controls.Add(this.BotonDeCalculo);
            this.Controls.Add(this.CajaDeTexto);
            this.Name = "ContadorDePalabras";
            this.Text = "Contador de palabras";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox CajaDeTexto;
        private System.Windows.Forms.Button BotonDeCalculo;
    }
}

