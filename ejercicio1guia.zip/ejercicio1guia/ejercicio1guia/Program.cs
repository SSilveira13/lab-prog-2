﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio1guia
{
    class Program
    {
        static void Main(string[] args)
        {
            /*int aux1;
            int aux2;
            int aux3;
            int aux4;
            int aux5;*/
            int numeroAuxiliar;
            int numMaximo=0;
            int numMinimo=0;
            int acumulador=0;
            int promedio;
            int i;
            for(i=1;i <= 5;i++)
            {
                Console.WriteLine("Ingrese un numero({0}):", i);
                numeroAuxiliar = Convert.ToInt32(Console.ReadLine());
                if (i == 1)
                {
                    numMinimo = numeroAuxiliar;
                    numMaximo = numeroAuxiliar;
                }
                if(numeroAuxiliar > numMaximo)
                {
                    numMaximo = numeroAuxiliar;
                }
                if (numeroAuxiliar < numMinimo)
                {
                    numMinimo = numeroAuxiliar;
                }
                acumulador = acumulador + numeroAuxiliar;
                /*switch(i)
                {
                    case 1:
                        aux1 = numeroAuxiliar;
                        break;
                    case 2:
                        aux2 = numeroAuxiliar;
                        break;
                    case 3:
                        aux3 = numeroAuxiliar;
                        break;
                    case 4:
                        aux4 = numeroAuxiliar;
                        break;
                    case 5:
                        aux5 = numeroAuxiliar;
                        break;
                }*/
            }
            promedio = acumulador / 5;
            Console.WriteLine("Maximo:{0} Minimo:{1} Promedio:{2}", numMaximo, numMinimo, promedio);
            Console.ReadKey();
        }
    }
}
