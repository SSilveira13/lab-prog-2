﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            double numero;
            double cuadrado;
            double cubo;
            Console.WriteLine("Ingrese un numero mayor a 0: ");
            numero = Convert.ToDouble(Console.ReadLine());
            if(numero > 0)
            {
                cuadrado = Math.Pow(numero, 2);
                cubo = Math.Pow(numero, 3);
                Console.Clear();
                Console.WriteLine("Cuadrado: {0} Cubo: {1}", cuadrado, cubo);
            }
            else
            {
                Console.Clear();
                Console.WriteLine("Error el numero es menor o igual a 0.");
            }
            Console.ReadKey();

        }
    }
}
