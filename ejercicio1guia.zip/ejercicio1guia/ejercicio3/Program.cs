﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio3
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            float resto;
            int divisible=0;
            int i;
            int j;
            Console.WriteLine("Ingrese un numero: ");
            numero = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Numeros primos: ");
            for(i=1;i<=numero;i++)
            {
                for(j=1;j<=i;j++)
                {
                    resto = i % j;
                    if (resto == 0)
                    {
                        divisible++;
                    }
                }
                if(divisible == 2 || i==1)
                {
                    Console.WriteLine("{0}", i);
                }
                divisible = 0;
            }
            Console.ReadKey();
        }
    }
}
