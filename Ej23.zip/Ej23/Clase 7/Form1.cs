﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Billetes;

namespace Clase_7
{
    public partial class VentanaPrincipal : Form
    {
        public VentanaPrincipal()
        {
            InitializeComponent();
        }

        private void LockUnlock_OnClick(object sender, EventArgs e)
        {
            this.LockUnlockBtn.ImageIndex = this.LockUnlockBtn.ImageIndex == 1 ? 0 : 1;//forma corta del ifelse

            this.EuroCambio.Enabled = !this.EuroCambio.Enabled;
            this.DolarCambio.Enabled = !this.DolarCambio.Enabled;
            this.PesoCambio.Enabled = !this.PesoCambio.Enabled;
        }

        private void VentanaPrincipal_Load(object sender, EventArgs e)
        {

        }

        private void BtnEuro_OnClick(object sender, EventArgs e)
        {
            double cantidad = Convert.ToDouble(TxtBxEuro.Text);
            Euros euro = new Euros(cantidad);
            Pesos peso = (Pesos)euro;
            Dolares dolar = (Dolares)euro;
            double cEuro = euro.getCantidad();
            double cPesos = peso.getCantidad();
            double cDolares = dolar.getCantidad();
            this.EuroToEuro.Text = Convert.ToString(cEuro);
            this.EuroToDolar.Text = Convert.ToString(cDolares);
            this.EuroToPeso.Text = Convert.ToString(cPesos);
        }

        private void BtnDolar_OnClick(object sender, EventArgs e)
        {
            double cantidad = Convert.ToDouble(TxtBxDolar.Text);
            Dolares dolar = new Dolares(cantidad);
            Pesos peso = (Pesos)dolar;
            Euros euro = (Euros)dolar;
            double cEuro = euro.getCantidad();
            double cPesos = peso.getCantidad();
            double cDolares = dolar.getCantidad();
            this.DolarToEuro.Text = Convert.ToString(cEuro);
            this.DolarToDolar.Text = Convert.ToString(cDolares);
            this.DolarToPeso.Text = Convert.ToString(cPesos);
        }

        private void BtnPeso_OnClick(object sender, EventArgs e)
        {
            double cantidad = Convert.ToDouble(TxtBxPeso.Text);
            Pesos peso = new Pesos(cantidad);
            Dolares dolar = (Dolares)peso;
            Euros euro = (Euros)peso;
            double cEuro = euro.getCantidad();
            double cPesos = peso.getCantidad();
            double cDolares = dolar.getCantidad();
            this.PesoToEuro.Text = Convert.ToString(cEuro);
            this.PesoToDolar.Text = Convert.ToString(cDolares);
            this.PesoToPeso.Text = Convert.ToString(cPesos);
        }

        private void CotizEuro_OnLeave(object sender, EventArgs e)
        {
            double cotiz = Convert.ToDouble(EuroCambio.Text);
            Euros euro = new Euros(0, cotiz);
        }

        private void CotizDolar_OnLeave(object sender, EventArgs e)
        {
            double cotiz = Convert.ToDouble(DolarCambio.Text);
            Dolares dolar = new Dolares(0, cotiz);
        }

        private void CotizPeso_OnLeave(object sender, EventArgs e)
        {
            double cotiz = Convert.ToDouble(PesoCambio.Text);
            Pesos peso = new Pesos(0, cotiz);
        }
    }
}
