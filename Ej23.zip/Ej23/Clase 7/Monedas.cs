﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    class Pesos
    {
        private double cantidad;
        private static double cotizRespectoDolar;
        
        #region Constructores
        static Pesos()
        {
            Pesos.cotizRespectoDolar = 38.33;
        }

        public Pesos(double cantidad, double cotiz) :this(cantidad)
        {
            Pesos.cotizRespectoDolar = cotiz;
        }

        public Pesos(double cantidad)
        {
            this.cantidad = cantidad;
        }
        #endregion
        #region Metodos
        #region Geters
        public static double getCotiz()
        {
            return cotizRespectoDolar;
        }
        public double getCantidad()
        {
            return this.cantidad;
        }
        #endregion
        #region Conversores
        public static explicit operator Dolares(Pesos p)
        {
            double cambio = p.cantidad / cotizRespectoDolar;
            Dolares retorno = new Dolares(cambio);
            return retorno;
        }
        public static explicit operator Euros(Pesos p)
        {
            double euroCotiz = Euros.getCotiz();
            double cambio = p.cantidad / cotizRespectoDolar / euroCotiz;
            Euros retorno = new Euros(cambio);
            return retorno;
        }
        #endregion
        #region Comparadores
        public static bool operator ==(Pesos p1, Pesos p2)
        {
            return p1 == p2;
        }
        public static bool operator !=(Pesos p1, Pesos p2)
        {
            return !(p1 == p2);
        }

        public static bool operator ==(Pesos p, Dolares d)
        {
            return (Dolares)p == d;
        }
        public static bool operator !=(Pesos p, Dolares d)
        {
            return !((Dolares)p == d);
        }

        public static bool operator ==(Pesos p, Euros e)
        {
            return (Euros)p == e;
        }
        public static bool operator !=(Pesos p, Euros e)
        {
            return !((Euros)p == e);
        }
        #endregion
        #region Aritmetica
        public static Pesos operator +(Pesos p, Euros e)
        {
            Pesos cambio = (Pesos)e;
            double cantidad = p.cantidad + cambio.cantidad;
            Pesos retorno = new Pesos(cantidad);
            return retorno;
        }
        public static Pesos operator +(Pesos p, Dolares d)
        {
            Pesos cambio = (Pesos)d;
            double cantidad = p.cantidad + cambio.cantidad;
            Pesos retorno = new Pesos(cantidad);
            return retorno;
        }

        public static Pesos operator -(Pesos p, Euros e)
        {
            Pesos cambio = (Pesos)e;
            double cantidad = p.cantidad - cambio.cantidad;
            if (cantidad < 0)
            {
                cantidad = cantidad * -1;
            }
            Pesos retorno = new Pesos(cantidad);
            return retorno;
        }
        public static Pesos operator -(Pesos p, Dolares d)
        {
            Pesos cambio = (Pesos)d;
            double cantidad = p.cantidad - cambio.cantidad;
            if (cantidad < 0)
            {
                cantidad = cantidad * -1;
            }
            Pesos retorno = new Pesos(cantidad);
            return retorno;
        }
        #endregion
        #endregion
    }

    class Euros
    {
        private double cantidad;
        private static double cotizRespectoDolar;
        private double cambio;

        #region Constructores
        static Euros()
        {
            Euros.cotizRespectoDolar = 1.16;
        }
        public Euros(double cantidad, double cotiz) :this(cantidad)
        {
            cotizRespectoDolar = cotiz;
        }
        public Euros(double cantidad)
        {
            this.cantidad = cantidad;
        }

        #endregion
        #region Metodos
        #region Geters
        public static double getCotiz()
        {
            return cotizRespectoDolar;
        }
        public double getCantidad()
        {
            return this.cantidad;
        }
        #endregion
        #region Conversores
        public static explicit operator Dolares(Euros e)
        {
            double cambio = e.cantidad * cotizRespectoDolar;
            Dolares retorno = new Dolares(cambio);
            return retorno;
        }
        public static explicit operator Pesos(Euros e)
        {
            double pesoCotiz = Pesos.getCotiz();
            double cambio = e.cantidad * cotizRespectoDolar * pesoCotiz;
            Pesos retorno = new Pesos(cambio);
            return retorno;
        }
        #endregion
        #region Comparadores
        public static bool operator ==(Euros e1, Euros e2)
        {
            return e1 == e2;
        }
        public static bool operator !=(Euros e1, Euros e2)
        {
            return !(e1 == e2);
        }

        public static bool operator ==(Euros e, Dolares d)
        {
            return (Dolares)e == d;
        }
        public static bool operator !=(Euros e, Dolares d)
        {
            return !((Dolares)e == d);
        }

        public static bool operator ==(Euros e, Pesos p)
        {
            return (Pesos)e == p;
        }
        public static bool operator !=(Euros e, Pesos p)
        {
            return !((Pesos)e == p);
        }
        #endregion
        #region Aritmetica
        public static Euros operator +(Euros e, Pesos p)
        {
            Euros cambio = (Euros)p;
            double cantidad = e.cantidad + cambio.cantidad;
            Euros retorno = new Euros(cantidad);
            return retorno;
        }
        public static Euros operator +(Euros e, Dolares d)
        {
            Euros cambio = (Euros)d;
            double cantidad = e.cantidad + cambio.cantidad;
            Euros retorno = new Euros(cantidad);
            return retorno;
        }

        public static Euros operator -(Euros e, Pesos p)
        {
            Euros cambio = (Euros)p;
            double cantidad = e.cantidad - cambio.cantidad;
            if (cantidad < 0)
            {
                cantidad = cantidad * -1;
            }
            Euros retorno = new Euros(cantidad);
            return retorno;
        }
        public static Euros operator -(Euros e, Dolares d)
        {
            Euros cambio = (Euros)d;
            double cantidad = e.cantidad - cambio.cantidad;
            if (cantidad < 0)
            {
                cantidad = cantidad * -1;
            }
            Euros retorno = new Euros(cantidad);
            return retorno;
        }
        #endregion
        #endregion
    }

    class Dolares
    {
        private double cantidad;
        private static double cotizRespectoDolar;
        private double cambio;

        #region Constructores
        static Dolares()
        {
            Dolares.cotizRespectoDolar = 1;
        }
        public Dolares(double cantidad, double cotiz) :this(cantidad)
        {
            cotizRespectoDolar = cotiz;
        }
        public Dolares(double cantidad)
        {
            this.cantidad = cantidad;
        }
        #endregion
        #region Metodos
        #region Geters
        public static double getCotiz()
        {
            return cotizRespectoDolar;
        }
        public double getCantidad()
        {
            return this.cantidad;
        }
        #endregion
        #region Conversores
        public static explicit operator Pesos(Dolares d)
        {
            double cotizPesos = Pesos.getCotiz();
            double cambio = d.cantidad * cotizPesos;
            Pesos retorno = new Pesos(cambio);
            return retorno;
        }
        public static explicit operator Euros(Dolares d)
        {
            double cotizEuros = Euros.getCotiz();
            double cambio = d.cantidad / cotizEuros;
            Euros retorno = new Euros(cambio);
            return retorno;
        }
        #endregion
        #region Comparadores
        public static bool operator ==(Dolares d1, Dolares d2)
        {
            return d1 == d2;
        }
        public static bool operator !=(Dolares d1, Dolares d2)
        {
            return !(d1 == d2);
        }

        public static bool operator ==(Dolares d, Euros e)
        {
            return (Euros)d == e;
        }
        public static bool operator !=(Dolares d, Euros e)
        {
            return !((Euros)d == e);
        }

        public static bool operator ==(Dolares d, Pesos p)
        {
            return (Pesos)d == p;
        }
        public static bool operator !=(Dolares d, Pesos p)
        {
            return !((Dolares)d == p);
        }
        #endregion
        #region Aritmetica
        public static Dolares operator +(Dolares d, Pesos p)
        {
            Dolares cambio = (Dolares)p;
            double cantidad = d.cantidad + cambio.cantidad;
            Dolares retorno = new Dolares(cantidad);
            return retorno;
        }
        public static Dolares operator +(Dolares d, Euros e)
        {
            Dolares cambio = (Dolares)e;
            double cantidad = d.cantidad + cambio.cantidad;
            Dolares retorno = new Dolares(cantidad);
            return retorno;
        }

        public static Dolares operator -(Dolares d, Euros e)
        {
            Dolares cambio = (Dolares)e;
            double cantidad = d.cantidad - cambio.cantidad;
            if (cantidad < 0)
            {
                cantidad = cantidad * -1;
            }
            Dolares retorno = new Dolares(cantidad);
            return retorno;
        }
        public static Dolares operator -(Dolares d, Pesos p)
        {
            Dolares cambio = (Dolares)p;
            double cantidad = d.cantidad - cambio.cantidad;
            if (cantidad < 0)
            {
                cantidad = cantidad * -1;
            }
            Dolares retorno = new Dolares(cantidad);
            return retorno;
        }
        #endregion
        #endregion
    }
}
