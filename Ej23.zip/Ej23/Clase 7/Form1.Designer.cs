﻿namespace Clase_7
{
    partial class VentanaPrincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VentanaPrincipal));
            this.PesoLbl = new System.Windows.Forms.Label();
            this.DolarLbl = new System.Windows.Forms.Label();
            this.EuroLbl = new System.Windows.Forms.Label();
            this.TxtBxEuro = new System.Windows.Forms.TextBox();
            this.TxtBxDolar = new System.Windows.Forms.TextBox();
            this.TxtBxPeso = new System.Windows.Forms.TextBox();
            this.BtnEuro = new System.Windows.Forms.Button();
            this.BtnDolar = new System.Windows.Forms.Button();
            this.BtnPeso = new System.Windows.Forms.Button();
            this.EuroToEuro = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.DolarToEuro = new System.Windows.Forms.TextBox();
            this.PesoToEuro = new System.Windows.Forms.TextBox();
            this.EuroToDolar = new System.Windows.Forms.TextBox();
            this.EuroToPeso = new System.Windows.Forms.TextBox();
            this.DolarToDolar = new System.Windows.Forms.TextBox();
            this.PesoToDolar = new System.Windows.Forms.TextBox();
            this.DolarToPeso = new System.Windows.Forms.TextBox();
            this.PesoToPeso = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.EuroCambio = new System.Windows.Forms.TextBox();
            this.DolarCambio = new System.Windows.Forms.TextBox();
            this.PesoCambio = new System.Windows.Forms.TextBox();
            this.CotizLbl = new System.Windows.Forms.Label();
            this.LockUnlockBtn = new System.Windows.Forms.Button();
            this.Candado = new System.Windows.Forms.ImageList(this.components);
            this.SuspendLayout();
            // 
            // PesoLbl
            // 
            this.PesoLbl.AutoSize = true;
            this.PesoLbl.Location = new System.Drawing.Point(12, 128);
            this.PesoLbl.Name = "PesoLbl";
            this.PesoLbl.Size = new System.Drawing.Size(35, 13);
            this.PesoLbl.TabIndex = 0;
            this.PesoLbl.Text = "Peso";
            // 
            // DolarLbl
            // 
            this.DolarLbl.AutoSize = true;
            this.DolarLbl.Location = new System.Drawing.Point(12, 102);
            this.DolarLbl.Name = "DolarLbl";
            this.DolarLbl.Size = new System.Drawing.Size(37, 13);
            this.DolarLbl.TabIndex = 1;
            this.DolarLbl.Text = "Dólar";
            // 
            // EuroLbl
            // 
            this.EuroLbl.AutoSize = true;
            this.EuroLbl.Location = new System.Drawing.Point(12, 76);
            this.EuroLbl.Name = "EuroLbl";
            this.EuroLbl.Size = new System.Drawing.Size(33, 13);
            this.EuroLbl.TabIndex = 2;
            this.EuroLbl.Text = "Euro";
            // 
            // TxtBxEuro
            // 
            this.TxtBxEuro.Location = new System.Drawing.Point(53, 73);
            this.TxtBxEuro.Name = "TxtBxEuro";
            this.TxtBxEuro.Size = new System.Drawing.Size(100, 20);
            this.TxtBxEuro.TabIndex = 3;
            // 
            // TxtBxDolar
            // 
            this.TxtBxDolar.Location = new System.Drawing.Point(53, 99);
            this.TxtBxDolar.Name = "TxtBxDolar";
            this.TxtBxDolar.Size = new System.Drawing.Size(100, 20);
            this.TxtBxDolar.TabIndex = 4;
            // 
            // TxtBxPeso
            // 
            this.TxtBxPeso.Location = new System.Drawing.Point(53, 125);
            this.TxtBxPeso.Name = "TxtBxPeso";
            this.TxtBxPeso.Size = new System.Drawing.Size(100, 20);
            this.TxtBxPeso.TabIndex = 5;
            // 
            // BtnEuro
            // 
            this.BtnEuro.Location = new System.Drawing.Point(159, 71);
            this.BtnEuro.Name = "BtnEuro";
            this.BtnEuro.Size = new System.Drawing.Size(71, 23);
            this.BtnEuro.TabIndex = 6;
            this.BtnEuro.Text = "->";
            this.BtnEuro.UseVisualStyleBackColor = true;
            this.BtnEuro.Click += new System.EventHandler(this.BtnEuro_OnClick);
            // 
            // BtnDolar
            // 
            this.BtnDolar.Location = new System.Drawing.Point(159, 97);
            this.BtnDolar.Name = "BtnDolar";
            this.BtnDolar.Size = new System.Drawing.Size(71, 23);
            this.BtnDolar.TabIndex = 7;
            this.BtnDolar.Text = "->";
            this.BtnDolar.UseVisualStyleBackColor = true;
            this.BtnDolar.Click += new System.EventHandler(this.BtnDolar_OnClick);
            // 
            // BtnPeso
            // 
            this.BtnPeso.Location = new System.Drawing.Point(159, 123);
            this.BtnPeso.Name = "BtnPeso";
            this.BtnPeso.Size = new System.Drawing.Size(71, 23);
            this.BtnPeso.TabIndex = 8;
            this.BtnPeso.Text = "->";
            this.BtnPeso.UseVisualStyleBackColor = true;
            this.BtnPeso.Click += new System.EventHandler(this.BtnPeso_OnClick);
            // 
            // EuroToEuro
            // 
            this.EuroToEuro.Enabled = false;
            this.EuroToEuro.Location = new System.Drawing.Point(236, 73);
            this.EuroToEuro.Name = "EuroToEuro";
            this.EuroToEuro.Size = new System.Drawing.Size(100, 20);
            this.EuroToEuro.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(270, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Euro";
            // 
            // DolarToEuro
            // 
            this.DolarToEuro.Location = new System.Drawing.Point(236, 99);
            this.DolarToEuro.Name = "DolarToEuro";
            this.DolarToEuro.Size = new System.Drawing.Size(100, 20);
            this.DolarToEuro.TabIndex = 11;
            // 
            // PesoToEuro
            // 
            this.PesoToEuro.Location = new System.Drawing.Point(236, 125);
            this.PesoToEuro.Name = "PesoToEuro";
            this.PesoToEuro.Size = new System.Drawing.Size(100, 20);
            this.PesoToEuro.TabIndex = 12;
            // 
            // EuroToDolar
            // 
            this.EuroToDolar.Location = new System.Drawing.Point(342, 73);
            this.EuroToDolar.Name = "EuroToDolar";
            this.EuroToDolar.Size = new System.Drawing.Size(100, 20);
            this.EuroToDolar.TabIndex = 13;
            // 
            // EuroToPeso
            // 
            this.EuroToPeso.Location = new System.Drawing.Point(448, 73);
            this.EuroToPeso.Name = "EuroToPeso";
            this.EuroToPeso.Size = new System.Drawing.Size(100, 20);
            this.EuroToPeso.TabIndex = 14;
            // 
            // DolarToDolar
            // 
            this.DolarToDolar.Location = new System.Drawing.Point(342, 99);
            this.DolarToDolar.Name = "DolarToDolar";
            this.DolarToDolar.Size = new System.Drawing.Size(100, 20);
            this.DolarToDolar.TabIndex = 15;
            // 
            // PesoToDolar
            // 
            this.PesoToDolar.Location = new System.Drawing.Point(342, 125);
            this.PesoToDolar.Name = "PesoToDolar";
            this.PesoToDolar.Size = new System.Drawing.Size(100, 20);
            this.PesoToDolar.TabIndex = 16;
            // 
            // DolarToPeso
            // 
            this.DolarToPeso.Location = new System.Drawing.Point(448, 99);
            this.DolarToPeso.Name = "DolarToPeso";
            this.DolarToPeso.Size = new System.Drawing.Size(100, 20);
            this.DolarToPeso.TabIndex = 17;
            // 
            // PesoToPeso
            // 
            this.PesoToPeso.Location = new System.Drawing.Point(448, 125);
            this.PesoToPeso.Name = "PesoToPeso";
            this.PesoToPeso.Size = new System.Drawing.Size(100, 20);
            this.PesoToPeso.TabIndex = 18;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(373, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "Dólar";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(479, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "Peso";
            // 
            // EuroCambio
            // 
            this.EuroCambio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EuroCambio.Location = new System.Drawing.Point(236, 12);
            this.EuroCambio.Name = "EuroCambio";
            this.EuroCambio.Size = new System.Drawing.Size(100, 20);
            this.EuroCambio.TabIndex = 21;
            this.EuroCambio.Leave += new System.EventHandler(this.CotizEuro_OnLeave);
            // 
            // DolarCambio
            // 
            this.DolarCambio.Location = new System.Drawing.Point(342, 12);
            this.DolarCambio.Name = "DolarCambio";
            this.DolarCambio.Size = new System.Drawing.Size(100, 20);
            this.DolarCambio.TabIndex = 22;
            this.DolarCambio.Leave += new System.EventHandler(this.CotizDolar_OnLeave);
            // 
            // PesoCambio
            // 
            this.PesoCambio.Location = new System.Drawing.Point(448, 12);
            this.PesoCambio.Name = "PesoCambio";
            this.PesoCambio.Size = new System.Drawing.Size(100, 20);
            this.PesoCambio.TabIndex = 23;
            this.PesoCambio.Leave += new System.EventHandler(this.CotizPeso_OnLeave);
            // 
            // CotizLbl
            // 
            this.CotizLbl.AutoSize = true;
            this.CotizLbl.Location = new System.Drawing.Point(87, 15);
            this.CotizLbl.Name = "CotizLbl";
            this.CotizLbl.Size = new System.Drawing.Size(66, 13);
            this.CotizLbl.TabIndex = 24;
            this.CotizLbl.Text = "Cotización";
            // 
            // LockUnlockBtn
            // 
            this.LockUnlockBtn.ImageIndex = 0;
            this.LockUnlockBtn.ImageList = this.Candado;
            this.LockUnlockBtn.Location = new System.Drawing.Point(159, 10);
            this.LockUnlockBtn.Name = "LockUnlockBtn";
            this.LockUnlockBtn.Size = new System.Drawing.Size(71, 23);
            this.LockUnlockBtn.TabIndex = 25;
            this.LockUnlockBtn.UseVisualStyleBackColor = true;
            this.LockUnlockBtn.Click += new System.EventHandler(this.LockUnlock_OnClick);
            // 
            // Candado
            // 
            this.Candado.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Candado.ImageStream")));
            this.Candado.TransparentColor = System.Drawing.Color.Transparent;
            this.Candado.Images.SetKeyName(0, "lock-open-solid.png");
            this.Candado.Images.SetKeyName(1, "lock-solid.png");
            // 
            // VentanaPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 150);
            this.Controls.Add(this.LockUnlockBtn);
            this.Controls.Add(this.CotizLbl);
            this.Controls.Add(this.PesoCambio);
            this.Controls.Add(this.DolarCambio);
            this.Controls.Add(this.EuroCambio);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.PesoToPeso);
            this.Controls.Add(this.DolarToPeso);
            this.Controls.Add(this.PesoToDolar);
            this.Controls.Add(this.DolarToDolar);
            this.Controls.Add(this.EuroToPeso);
            this.Controls.Add(this.EuroToDolar);
            this.Controls.Add(this.PesoToEuro);
            this.Controls.Add(this.DolarToEuro);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.EuroToEuro);
            this.Controls.Add(this.BtnPeso);
            this.Controls.Add(this.BtnDolar);
            this.Controls.Add(this.BtnEuro);
            this.Controls.Add(this.TxtBxPeso);
            this.Controls.Add(this.TxtBxDolar);
            this.Controls.Add(this.TxtBxEuro);
            this.Controls.Add(this.EuroLbl);
            this.Controls.Add(this.DolarLbl);
            this.Controls.Add(this.PesoLbl);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "VentanaPrincipal";
            this.Text = "Conversor";
            this.Load += new System.EventHandler(this.VentanaPrincipal_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label PesoLbl;
        private System.Windows.Forms.Label DolarLbl;
        private System.Windows.Forms.Label EuroLbl;
        private System.Windows.Forms.TextBox TxtBxEuro;
        private System.Windows.Forms.TextBox TxtBxDolar;
        private System.Windows.Forms.TextBox TxtBxPeso;
        private System.Windows.Forms.Button BtnEuro;
        private System.Windows.Forms.Button BtnDolar;
        private System.Windows.Forms.Button BtnPeso;
        private System.Windows.Forms.TextBox EuroToEuro;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox DolarToEuro;
        private System.Windows.Forms.TextBox PesoToEuro;
        private System.Windows.Forms.TextBox EuroToDolar;
        private System.Windows.Forms.TextBox EuroToPeso;
        private System.Windows.Forms.TextBox DolarToDolar;
        private System.Windows.Forms.TextBox PesoToDolar;
        private System.Windows.Forms.TextBox DolarToPeso;
        private System.Windows.Forms.TextBox PesoToPeso;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox EuroCambio;
        private System.Windows.Forms.TextBox DolarCambio;
        private System.Windows.Forms.TextBox PesoCambio;
        private System.Windows.Forms.Label CotizLbl;
        private System.Windows.Forms.Button LockUnlockBtn;
        private System.Windows.Forms.ImageList Candado;
    }
}

