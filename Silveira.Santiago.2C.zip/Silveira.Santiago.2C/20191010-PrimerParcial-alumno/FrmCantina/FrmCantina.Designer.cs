﻿namespace FrmCantina
{
    partial class FrmCantina
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.MarcaLbl = new System.Windows.Forms.Label();
            this.TipoLbl = new System.Windows.Forms.Label();
            this.TxtBoxMarcas = new System.Windows.Forms.TextBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.TipoCmbBx = new System.Windows.Forms.ComboBox();
            this.AgregarBtn = new System.Windows.Forms.Button();
            this.CervezaRButton = new System.Windows.Forms.RadioButton();
            this.AguaRButton = new System.Windows.Forms.RadioButton();
            this.CapLbl = new System.Windows.Forms.Label();
            this.ContLbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            this.SuspendLayout();
            // 
            // MarcaLbl
            // 
            this.MarcaLbl.AutoSize = true;
            this.MarcaLbl.Location = new System.Drawing.Point(216, 300);
            this.MarcaLbl.Name = "MarcaLbl";
            this.MarcaLbl.Size = new System.Drawing.Size(37, 13);
            this.MarcaLbl.TabIndex = 0;
            this.MarcaLbl.Text = "Marca";
            // 
            // TipoLbl
            // 
            this.TipoLbl.AutoSize = true;
            this.TipoLbl.Location = new System.Drawing.Point(463, 300);
            this.TipoLbl.Name = "TipoLbl";
            this.TipoLbl.Size = new System.Drawing.Size(63, 13);
            this.TipoLbl.TabIndex = 1;
            this.TipoLbl.Text = "Botella Tipo";
            // 
            // TxtBoxMarcas
            // 
            this.TxtBoxMarcas.Location = new System.Drawing.Point(219, 317);
            this.TxtBoxMarcas.Name = "TxtBoxMarcas";
            this.TxtBoxMarcas.Size = new System.Drawing.Size(210, 20);
            this.TxtBoxMarcas.TabIndex = 2;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(219, 374);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(57, 20);
            this.numericUpDown1.TabIndex = 3;
            this.numericUpDown1.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(372, 374);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(57, 20);
            this.numericUpDown2.TabIndex = 4;
            this.numericUpDown2.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // TipoCmbBx
            // 
            this.TipoCmbBx.FormattingEnabled = true;
            this.TipoCmbBx.Location = new System.Drawing.Point(466, 317);
            this.TipoCmbBx.Name = "TipoCmbBx";
            this.TipoCmbBx.Size = new System.Drawing.Size(121, 21);
            this.TipoCmbBx.TabIndex = 5;
            // 
            // AgregarBtn
            // 
            this.AgregarBtn.Location = new System.Drawing.Point(466, 358);
            this.AgregarBtn.Name = "AgregarBtn";
            this.AgregarBtn.Size = new System.Drawing.Size(121, 38);
            this.AgregarBtn.TabIndex = 6;
            this.AgregarBtn.Text = "Agregar";
            this.AgregarBtn.UseVisualStyleBackColor = true;
            // 
            // CervezaRButton
            // 
            this.CervezaRButton.AutoSize = true;
            this.CervezaRButton.Location = new System.Drawing.Point(12, 318);
            this.CervezaRButton.Name = "CervezaRButton";
            this.CervezaRButton.Size = new System.Drawing.Size(64, 17);
            this.CervezaRButton.TabIndex = 7;
            this.CervezaRButton.TabStop = true;
            this.CervezaRButton.Text = "Cerveza";
            this.CervezaRButton.UseVisualStyleBackColor = true;
            // 
            // AguaRButton
            // 
            this.AguaRButton.AutoSize = true;
            this.AguaRButton.Location = new System.Drawing.Point(12, 341);
            this.AguaRButton.Name = "AguaRButton";
            this.AguaRButton.Size = new System.Drawing.Size(50, 17);
            this.AguaRButton.TabIndex = 8;
            this.AguaRButton.TabStop = true;
            this.AguaRButton.Text = "Agua";
            this.AguaRButton.UseVisualStyleBackColor = true;
            // 
            // CapLbl
            // 
            this.CapLbl.AutoSize = true;
            this.CapLbl.Location = new System.Drawing.Point(216, 358);
            this.CapLbl.Name = "CapLbl";
            this.CapLbl.Size = new System.Drawing.Size(58, 13);
            this.CapLbl.TabIndex = 9;
            this.CapLbl.Text = "Capacidad";
            // 
            // ContLbl
            // 
            this.ContLbl.AutoSize = true;
            this.ContLbl.Location = new System.Drawing.Point(369, 358);
            this.ContLbl.Name = "ContLbl";
            this.ContLbl.Size = new System.Drawing.Size(55, 13);
            this.ContLbl.TabIndex = 10;
            this.ContLbl.Text = "Contenido";
            // 
            // FrmCantina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(597, 450);
            this.Controls.Add(this.ContLbl);
            this.Controls.Add(this.CapLbl);
            this.Controls.Add(this.AguaRButton);
            this.Controls.Add(this.CervezaRButton);
            this.Controls.Add(this.AgregarBtn);
            this.Controls.Add(this.TipoCmbBx);
            this.Controls.Add(this.numericUpDown2);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.TxtBoxMarcas);
            this.Controls.Add(this.TipoLbl);
            this.Controls.Add(this.MarcaLbl);
            this.Name = "FrmCantina";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FrmCantina_OnLoad);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label MarcaLbl;
        private System.Windows.Forms.Label TipoLbl;
        private System.Windows.Forms.TextBox TxtBoxMarcas;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.ComboBox TipoCmbBx;
        private System.Windows.Forms.Button AgregarBtn;
        private System.Windows.Forms.RadioButton CervezaRButton;
        private System.Windows.Forms.RadioButton AguaRButton;
        private System.Windows.Forms.Label CapLbl;
        private System.Windows.Forms.Label ContLbl;
    }
}

