﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrmCantina
{
    public partial class FrmCantina : Form
    {
        public FrmCantina()
        {
            InitializeComponent();
        }

        private void FrmCantina_OnLoad(object sender, EventArgs e)
        {
            TipoCmbBx.DataSource = Enum.GetValues(typeof(Entidades.Botella.Tipo));
        }
    }
}
