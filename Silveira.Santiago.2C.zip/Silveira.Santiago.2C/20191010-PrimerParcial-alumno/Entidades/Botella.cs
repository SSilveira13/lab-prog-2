﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Botella
    {
        int capacidadML;//mililitros
        int contenidoML;//   ''
        string marca;
        public enum Tipo
        {
            Plastico,
            Vidrio
        }

        #region Constructores
        public Botella(string marca, int capacidadML, int contenidoML)
        {
            if (capacidadML < contenidoML)
            {
                this.marca = marca;
                this.capacidadML = capacidadML;
                this.contenidoML = capacidadML;
            }
        }
        #endregion
        #region Propiedades
        public int CapacidadLitros
        {
            get
            {
                return this.capacidadML / 1000;
            }
        }
        public float PorcentajeContenido
        {
            get
            {
                float porcentaje;
                porcentaje = this.capacidadML * 100 / this.contenidoML;
                return porcentaje;
            }
        }
        public int Contenido
        {
            get
            {
                return this.contenidoML;
            }
            set
            {
                if(value < this.capacidadML)
                {
                    this.contenidoML = value;
                }
            }
        }
        #endregion
        #region Metodos
        public virtual int ServirMedida(int medida)
        {
            int resultado;
            if(medida<=this.contenidoML)
            {
                this.contenidoML -= medida;
                resultado = medida;
            }
            else
            {
                resultado = this.contenidoML;
                this.contenidoML = 0;
            }
            return resultado;
        }
        internal string GenerarInforme()
        {
            StringBuilder informe = new StringBuilder();
            informe.AppendFormat("Marca: {0} Capacidad: {1} Contenido: {2}\n",this.marca,this.capacidadML,this.contenidoML);
            return informe.ToString();
        }
        public string ToString()
        {
            return this.GenerarInforme();
        }
        #endregion
    }
}
