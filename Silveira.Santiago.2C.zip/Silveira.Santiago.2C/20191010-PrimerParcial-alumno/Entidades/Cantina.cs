﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Cantina
    {
        List<Botella> botellas;
        int espaciosTotales;
        private static Cantina Singleton;

        #region Constructor
        private Cantina(int espaciosTotales)
        {
            this.botellas = new List<Botella>();
            this.espaciosTotales = espaciosTotales;
        }
        #endregion
        #region Propiedades
        public List<Botella> Botellas
        {
            get
            {
                return this.botellas;
            }
        }
        #endregion
        #region Singleton
        public static Cantina GetCantina(int espaciosTotales)
        {
            Cantina retorno = null;
            if (Cantina.Singleton == null)
            {
                Cantina.Singleton = new Cantina(espaciosTotales);
                retorno = Cantina.Singleton;
            }
            else
            {
                Cantina.Singleton.espaciosTotales = espaciosTotales;
                retorno = Cantina.Singleton;
            }
            return retorno;
        }
        public static bool operator +(Cantina c, Botella b)
        {
            bool retorno = false;
            int ocupados = 0;
            foreach (Botella botella in c.botellas)
            {
                ocupados++;
            }
            if(ocupados < c.espaciosTotales)
            {
                retorno = true;
                c.botellas.Add(b);
            }
            return retorno;
        }
        #endregion
    }
}
