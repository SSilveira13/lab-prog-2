﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Agua : Botella
    {
        const int MEDIDA = 400;

        #region Constructores
        public Agua(string marca, int capacidadML, int contenidoML) : base( marca, capacidadML, contenidoML)
        {

        }
        #endregion
        #region Metodos
        int ServirMedida(int medida)
        {
            return this.ServirMedida(medida);
        }

        int ServirMedida()
        {
            return this.ServirMedida(MEDIDA);
        }

        string GenerarInforme()
        {
            return this.ToString();
        }
        #endregion
    }
}
