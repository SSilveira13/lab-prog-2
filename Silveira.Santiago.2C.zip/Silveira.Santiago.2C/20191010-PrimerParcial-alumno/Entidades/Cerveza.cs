﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Cerveza : Botella
    {
        const int MEDIDA = 330;
        Tipo tipo;
        #region Constructores
        public Cerveza(string marca, int capacidadML , int contenidoML, Tipo tipo) : base(marca,capacidadML,contenidoML) 
        {
            this.tipo = tipo;
        }
        public Cerveza(string marca, int capacidadML, int contenidoML) : this(marca,capacidadML,contenidoML,Tipo.Vidrio)
        {

        }
        #endregion
        #region Metodos
        public int ServirMedida()
        {
            double medidaFinal = MEDIDA * 0.8;
            int medidaInt = Convert.ToInt32(medidaFinal);
            int resultado = 0;
            if(medidaFinal < this.Contenido)
            {
                this.Contenido = this.Contenido - medidaInt;
                resultado = medidaInt;
            }
            else
            {
                resultado = this.Contenido;
                this.Contenido = 0;
            }
            return resultado;
        }
        string GenerarInforme()
        {
            StringBuilder informe = new StringBuilder();
            informe.AppendFormat("Tipo: {0} {1}", this.tipo, this.ToString());
            return informe.ToString();
        }


        #endregion
    }
}
